<?xml version="1.0" encoding="UTF-8"?>
<tileset name="sky" tilewidth="32" tileheight="32" tilecount="784" columns="28">
 <image source="sky.png" width="900" height="900"/>
</tileset>
