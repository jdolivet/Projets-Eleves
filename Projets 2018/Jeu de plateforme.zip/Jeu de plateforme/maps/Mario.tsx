<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Mario" tilewidth="32" tileheight="32" tilecount="880" columns="40">
 <image source="Mario.png" width="1280" height="720"/>
</tileset>
