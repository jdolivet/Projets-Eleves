<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tilesheet_complete" tilewidth="32" tileheight="32" tilecount="2160" columns="54">
 <image source="tilesheet_complete.png" width="1728" height="1280"/>
</tileset>
