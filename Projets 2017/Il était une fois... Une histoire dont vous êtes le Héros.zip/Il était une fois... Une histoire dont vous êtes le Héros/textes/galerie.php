<?php include 'head-header-menu.php';?>

<style>
div.galerie{
    padding: 5px;
	margin: auto;
    width: 800px;
    height: auto;
    font-size: 80%;
    font-family: 'Nunito Sans', sans-serif;
	border: 1px solid gray;
	border-radius: 5px;

}
div.dessin{
    margin: 5px;
    width: 250px;
    float: left;
	border: none;
    cursor: pointer;
	border-style: none;
    border-width: thin;
    margin: 10px 0px;
    background-color: lightgrey;
    border-radius: 5px;
}
div.dessin:hover{
    border:1px solid #777;
	background-color: rgb(30, 30, 50);
    color: white;
    cursor: pointer;
	
}
div.dessin img{
    width: 100%;
    height: auto;
    margin: auto;
}
div.desc{
    padding: 15px;
    text-align: center;
}


</style>

<div id = "main" onclick = "FermeMenu()">

    <div class="galerie">
        <div class="dessin">
            <a target="_blank" href="images/image1.jpg">
                <img src="images/image1.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>

        <div class="dessin">
            <a target="_blank" href="images/image2.jpg">
                <img src="images/image2.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>

        <div class="dessin">
            <a target="_blank" href="images/image3.jpg">
                <img src="images/image3.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>
    </div>

    <br>

    <div class="galerie">
        <div class="dessin">
            <a target="_blank" href="images/image4.jpg">
                <img src="images/image4.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>

        <div class="dessin">
            <a target="_blank" href="images/image5.jpg">
                <img src="images/image5.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>

        <div class="dessin">
            <a target="_blank" href="images/image6.jpg">
                <img src="images/image6.jpg" alt="lololol">
            </a>
            <div class="descr">CECI EST UNE DESCRIPTION </div>
        </div>
    </div>

    <br>


</div>


</body>