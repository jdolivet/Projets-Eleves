<?php include 'head-header-menu.php'; ?>





<!-- HTML avec les éléments qui s'afficherons -->

    <div id = "main" onclick = "FermeMenu()">
        <div id = "loader"></div>
        <h3 id = "horloge"></h3>
        <img id = "imageAffiche" onload="TestLoad('image')" src = "">
        <div id = "texteAffiche">
        </div>
    </div>





<!-- Partie du code en PHP qui est exécutée lorsque l'utilisateur s'inscrit ou réinitialise son mot de passe -->

    <?php

        //Après inscription

        $pseudo = htmlspecialchars($_POST["pseudo"]); //la fonction htmlspecialchars() empêche les utilisateurs d'insérer du code
        $mdp = htmlspecialchars($_POST["mdp"]);
        $question = htmlspecialchars($_POST["question"]);
        $reponse = htmlspecialchars($_POST["reponse"]);
        $nouv_mdp = htmlspecialchars($_POST["nouv_mdp"]);

        //Session est une variable superglobale, ce qui permettra d'utiliser le pseudo de l'utilisateur dans toutes les pages du site tant que sa session est ouverte.
        $_SESSION["pseudo"] = $pseudo;

        //on ajoute le nouveau compte au csv des comptes si les variables sont toutes remplies
        if (($_SERVER["REQUEST_METHOD"] == "POST")&&(isset($_POST["pseudo"],$_POST["mdp"],$_POST["question"],$_POST["reponse"]))) {
            // La fonction file transforme chaque ligne d'un fichier en élément d'un array
            // La fonction array_map exécute la fonction str_csv sur chacun des élément de l'array créé grâce à file
            // La fonction str_getcsv sépare les éléments de chaque ligne en éléments d'un array
            $csv = array_map("str_getcsv", file("comptes.csv"));
            //array avec les données du compte (pseudonyme, mdp, id de question de securite, réponse de quest, état présent dans le jeu, liste de tous les choix faits)
            $nouveau_compte = array($pseudo,$mdp,$question,$reponse,"000","");
            // On rajoutte l'array du nouveau compte au csv
            array_push($csv,$nouveau_compte);
            // On transforme le $csv format array d'arrays en chaîne de caractères en format csv
            $nouveau_contenu = "";
            foreach ($csv as $ligne) {
                $nouveau_contenu .= implode(",", $ligne)."\r\n";
            };

            // On remplace le contenu du fichier comptes par le contenu modifié
            $fichier = fopen("comptes.csv", "w");
            fputs($fichier, $nouveau_contenu);
            fclose($fichier);
        }


        //Après réinitialisation mdp

        //si les variables de reinitialisation de mdp sont remplies, on modifie le mdp
        if (($_SERVER["REQUEST_METHOD"] == "POST") && (isset($_POST["pseudo"], $_POST["nouv_mdp"]))) { 
            // La fonction file transforme chaque ligne d'un fichier en élément d'un array
            // La fonction array_map exécute la fonction str_csv sur chacun des élément de l'array créé grâce à file
            // La fonction str_getcsv sépare les éléments de chaque ligne en éléments d'un array
            $csv = array_map("str_getcsv", file("comptes.csv"));
            $idCompte = 0; //on cherche à quelle ligne sont les données correspondant au pseudoyme
            foreach ($csv as $ligne) {
                if ($ligne[0] == $pseudo){
                    $csv[$idCompte][1] = $nouv_mdp; //On modifie le mdp
                    break;
                }
                ++$idCompte;
            }
            //On transforme le $csv format array d'arrays en chaîne de caractères en format csv
            $nouveau_contenu = "";
            foreach ($csv as $ligne) {
                $nouveau_contenu .= implode(",", $ligne)."\r\n";
            }
            //On remplace le contenu du fichier comptes par le contenu modifié
            $fichier = fopen("comptes.csv", "w");
            fputs($fichier, $nouveau_contenu);
            fclose($fichier);
        }
        
    ?>





<!-- Javascript du programme -->

<script>




    //Cette fonction vérifie si l'image et le texte sont tous les deux chargés avant de les afficher.
    //Cela est nécessaire car AJAX étant asynchrone les deux ne chargent pas au même moment.

    var textediff = "blabla"; 
    var imagechargee = false;
    var textecharge = false;

    function TestLoad(element) {
        if (element == "image") {
            imagechargee = true;
        } 
        //Il n'y a pas de onload pour les textes, donc on teste si le texte a déjà été modifié.
        if (textediff != document.getElementById('texteAffiche').innerHTML) { 
            textecharge = true;
        }
        if (textecharge && imagechargee) {
            document.getElementById('loader').style.display = "none";
            document.getElementById('imageAffiche').style.display = "block";
            document.getElementById('texteAffiche').style.display = "block";
        }
    }




    //Cette fonction crée un objet requête qui permet de dialoguer avec le serveur grâce à AJAX.
    //Elle sera utilisée plusieurs fois par la suite.

    function CreeRequete() {
        //On crée un objet XMLHttpRequest, qui sert à dialoguer avec le serveur.
        if (window.XMLHttpRequest) {
            //Code pour naviageturs modernes
            var requete = new XMLHttpRequest();
        } else {
            //Code pour anciennes versions d'IE
            var requete = new ActiveXObject("Microsoft.XMLHTTP");
        }
        return requete;
    }




    //Cette fonction trouve l'état actuel correspondant au pseudo de l'utilisateur sur comptes.csv

    <?php
		$csv = array_map("str_getcsv", file("comptes.csv")); //On transforme le csv des comptes en array d'arrays pour le lire plus tard.
	?>
    function TrouveEtat() {
        //On transforme un array de php en array de javascript.
		JScsv = <?php echo json_encode($csv) ?>;
		var idCompte = 1;
		while ((JScsv[idCompte][0] != "<?php echo $pseudo ?>")&&(idCompte<JScsv.length)) {
			idCompte +=1;
		}
        var idE = JScsv[idCompte][4];
        idT = idE.slice(0,2);
        idI = idE.slice(2);
        ModifieEtat(idT, idI);
    }




    //Cette fonction demande au serveur la prochaine image et prochain texte.

    function ModifieEtat(idTexte, idImage) {

        document.getElementById('loader').style.display = "block";
        imagechargee = false;
        textecharge = false;
        document.getElementById('imageAffiche').style.display = "none";
        document.getElementById('texteAffiche').style.display = "none";

        //On modifie l'image.
        var prochaineImage = 'images/imageX.jpg'.replace("X", idImage);
        if (document.getElementById('imageAffiche').src !== prochaineImage) {
            document.getElementById('imageAffiche').src = prochaineImage;
        }


        //On crée l'URL à demander au serveur à partir de l'état.
        prochainTexte = 'textes/texteX.txt'.replace("X", idTexte);


        var requeteTexte = CreeRequete();
        //Cette fontion anonyme va traiter le résultat à chaque fois que l'état de la requête change.
        requeteTexte.onreadystatechange = function() {
            //Si l'état de la requête vaut 4, cela veut dire que la réponse du serveur a été reçue dans son intégralité (après les étapes 0, 1, 2 et 3).
            //On vérifie ensuite le code d'état de la réponse du serveur. Le code 200 veut dire OK. 
            if (requeteTexte.readyState == 4 && requeteTexte.status == 200) {
                //responseText de la requête nous renvoie la réponse du serveur sous la forme du chaîne de texte, qu'on place dans la div "texteAffiche".
                document.getElementById("texteAffiche").innerHTML = requeteTexte.responseText;
            }
        }
        //On lance la requête avec la méthode open de l'objet XMLHttpRequest. Les paramètres correspondent, respectivement, à la méthode de requête, 
        //à l'URL de la page demandée et à true si la requête est asynchrone.
        requeteTexte.open("POST", prochainTexte, true);
        requeteTexte.send();

        var requeteTraiteEtat = CreeRequete();
        requeteTraiteEtat.open("GET", "traiteetat.php?idEtat=" + idTexte + idImage + "&pseudo=<?php echo $pseudo ?>", true);
        requeteTraiteEtat.send();

    }




    //Chaque fois que le joueur fait un choix, cette fonction l'envoie pour actualiser les statistiques et aussi ses paramètres dans comptes.csv

    function EnvoieChoix(choix) {

        var requeteSondage = CreeRequete();
        requeteSondage.open("GET", "sondage.php?choix="+choix, true);
        requeteSondage.send();

        var requeteTraiteChoix = CreeRequete();
        requeteTraiteChoix.open("GET", "traitechoix.php?choix=" + choix + "&pseudo=<?php echo $pseudo ?>", true);
        requeteTraiteChoix.send();

    }




    // Fonction exécutée à la fin du jeu qui permet d'accéder aux statistiques et à la galerie d'images.

    function FinJeu() {
        document.getElementById("boutonStat").href = "/statistiques.php?idFin";
    }




    
    //Cette fonction crée et contrôle le labyrinthe.

    function Labyrinthe(idLabyrinthe) {

        document.getElementById("texteAffiche").innerHTML = "<p id = 'instructions'>À vous de jouer : utilisez les flèches du clavier pour aider notre héros à traverser la forêt d'épines. Attention au temps !</p>";
        document.getElementById("imageAffiche").src = "";

        var espaceJeu = new Object();

        espaceJeu.start();
            
        espaceJeu.canvas = document.createElement("canvas");

        espaceJeu.start = function() {
            this.canvas.width = 484;
            this.canvas.height = 374;
            this.context = this.canvas.getContext("2d");
            document.getElementById("horloge").style.display = "inline-block";
            document.getElementById("main").insertBefore(espaceJeu.canvas, document.getElementById("imageAffiche"));
            this.interval = setInterval(updateEspaceJeu, 150); //l'actualisation de l'espace se fait toutes les 150 ms
            window.addEventListener('keydown', function (e) { 
                if([37, 38, 39, 40].indexOf(e.keyCode) > -1) { //37, 38, 39, 40 correspondent aux flèches du clavier.
                        e.preventDefault(); //On empêche les flèches de réaliser leur fonction par défaut, celle de scroll la page.
                    }
                    espaceJeu.key = e.keyCode;
            })
            window.addEventListener('keyup', function (e) {
                    espaceJeu.key = false;
            })
        }
                
        espaceJeu.clear = function() {
            this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
        }

        espaceJeu.stop = function(resultat) {
            clearInterval(this.interval);
            if (resultat == "succes") {
                document.getElementById("texteAffiche").innerHTML = "<ul><li class = 'boutonProchain' onclick = 'SuccesLabyrinthe(" + idLabyrinthe + ")'> Continuer </li></ul>";
            } else {
                document.getElementById("texteAffiche").innerHTML = "<p>Malheuresement non</p><ul><li class = 'boutonProchain' onclick = 'EchecLabyrinthe(" + idLabyrinthe + ")'> Continuer </li></ul>";
            }
        }

        function component(width, height, source, x, y) {
            this.image = new Image();
            this.image.src = source;
            this.width = width;
            this.height = height;
            this.x = x;
            this.y = y;
            this.update = function() {
                ctx = espaceJeu.context;
                ctx.drawImage(this.image, 
                    this.x, 
                    this.y,
                    this.width,
                    this.height);
            }
        }
        
        var murs = new component(484, 374, "images/labyrinthe.gif", 0, 0);
        var prince = new component(20, 20, "images/prince.gif", 22, 44);
        var porte = new component(20, 20, "images/fin.gif", 440 , 330);
        var temps = 10000;

        var coordonnees =[ // pour chaque case du labyrinthe, définit si le joueur peut passer (1) ou s'il y a un mur (0) (gauche, droite, haut, bas)
        [[0,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,1],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,0,0],[0,1,0,1],[1,1,0,0],[1,1,0,1],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,0,1]],
        [[0,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,1],[1,1,0,1],[1,1,0,0],[1,0,1,0],[0,0,0,1],[0,1,0,1],[1,1,0,0],[1,1,0,1],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,1,0,0],[1,0,0,1],[0,0,1,1]],
        [[0,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,0,0],[0,0,1,1],[0,0,1,1],[0,1,0,0],[1,1,0,0],[1,0,1,1],[0,0,1,0],[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,0,1,0],[0,1,0,0],[1,0,1,0],[0,0,1,1]],
        [[0,1,1,1],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,1,0],[1,1,0,0],[1,0,0,0],[0,1,1,1],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,1,1,0],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,1,1]],
        [[0,0,1,1],[0,1,0,1],[1,1,0,1],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,1,0],[1,1,0,0],[1,0,0,1],[0,0,1,1],[0,1,0,1],[1,1,0,0],[1,1,0,1],[1,0,0,0],[0,1,0,1],[1,1,0,0],[1,0,0,0],[0,0,1,0]],
        [[0,0,1,1],[0,0,1,1],[0,0,1,0],[0,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,0,0],[0,1,0,1],[1,1,0,1],[1,0,0,0],[0,0,1,0],[0,0,1,1],[0,0,1,1],[0,0,0,1],[0,1,1,0],[1,0,0,1],[0,0,1,1],[0,1,0,1],[1,1,0,0],[1,0,0,1]],
        [[0,1,1,1],[1,1,1,0],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,1,0,1],[1,0,0,1],[0,0,1,1],[0,0,1,0],[0,1,0,1],[1,1,0,0],[1,1,1,0],[1,0,1,0],[0,1,1,1],[1,0,0,1],[0,0,1,0],[0,0,1,1],[0,1,1,0],[1,0,0,1],[0,0,1,1]],
        [[0,1,1,0],[1,0,0,0],[0,1,0,1],[1,1,0,0],[1,0,1,1],[0,0,1,1],[0,1,1,0],[1,1,1,0],[1,1,0,0],[1,0,1,0],[0,0,0,1],[0,1,0,1],[1,1,0,0],[1,0,1,1],[0,1,1,1],[1,1,0,0],[1,1,1,0],[1,0,0,0],[0,0,1,1],[0,0,1,1]],
        [[0,1,0,1],[1,1,0,0],[1,0,1,0],[0,0,0,1],[0,0,1,1],[0,1,1,0],[1,0,0,0],[0,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,0,1,0],[0,1,0,1],[1,0,1,0],[0,0,1,1],[0,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,0,1,1]],
        [[0,0,1,1],[0,1,0,0],[1,1,0,0],[1,0,1,1],[0,1,1,0],[1,1,0,0],[1,0,0,0],[0,0,1,1],[0,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,0,1],[0,0,1,1],[0,1,0,1],[1,0,1,0],[0,1,1,1],[1,1,0,0],[1,1,0,0],[1,0,0,1],[0,0,1,1]],
        [[0,1,1,0],[1,1,0,1],[1,1,0,0],[1,1,1,0],[1,1,0,0],[1,1,0,1],[1,0,0,0],[0,1,1,1],[1,1,1,0],[1,1,0,0],[1,0,0,1],[0,1,1,0],[1,0,1,0],[0,1,1,0],[1,1,0,0],[1,0,1,0],[0,1,0,0],[1,0,0,1],[0,0,1,0],[0,0,1,1]],
        [[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,0,0,0],[0,1,0,1],[1,1,1,0],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,0,0,1],[0,1,1,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,0,0],[0,1,0,1],[1,1,1,0],[1,1,0,0],[1,0,1,1]],
        [[0,0,1,1],[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,1,0,0],[1,0,0,0],[0,0,1,1],[0,1,1,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,0,0,0],[0,0,1,1]],
        [[0,0,1,1],[0,1,1,0],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,0,1,0],[0,1,0,1],[1,1,0,0],[1,0,1,0],[0,1,0,1],[1,1,0,1],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,1],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,0,0],[1,0,1,0]],
        [[0,1,1,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,0,0],[1,1,1,0],[1,1,0,0],[1,1,0,0],[1,0,1,0],[0,1,1,0],[1,1,0,0],[1,1,0,0],[1,0,0,0],[0,1,1,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[1,1,0,0],[0,0,0,0]]
        ]

        function updateEspaceJeu() { // arrête le jeu si le prince arrive sur la porte, sinon réactualise l'espace et la position des objets
        if (prince.x==porte.x && prince.y==porte.y) {
                espaceJeu.stop("succes"); //jeu gagne
            }
            else { //les murs et la porte restent au même endroit et la position du prince se modifie selon les commandes du joueur s'il n'y a pas de mur (coordonnées)
                espaceJeu.clear();
                murs.update();
                porte.update();
                if ((espaceJeu.key && espaceJeu.key == 37) && coordonnees[prince.y/22-1][prince.x/22-1][0] == 1) {prince.x += -22;} //gauche
                if ((espaceJeu.key && espaceJeu.key == 39) && coordonnees[prince.y/22-1][prince.x/22-1][1] == 1) {prince.x += 22; } //droite
                if ((espaceJeu.key && espaceJeu.key == 38) && coordonnees[prince.y/22-1][prince.x/22-1][2] == 1) {prince.y += -22; } //haut
                if ((espaceJeu.key && espaceJeu.key == 40) && coordonnees[prince.y/22-1][prince.x/22-1][3] == 1) {prince.y += 22; } //bas
                prince.update();
                }
            
            
            temps -= 150;
            if (temps <= 0) {
                espaceJeu.stop("echec"); //jeu perdu
                document.getElementById("horloge").innerHTML = "Perdu :P";
            } else {
                minutes = Math.floor(temps/60000);
                secondes = Math.floor((temps % 60000) / 1000);
                document.getElementById("horloge").innerHTML = minutes + ":" + secondes;
            }
        }

    }


    //Fonction qui sort du labyrinthe si l'utilisateur est vainqueur.

    function SuccesLabyrinthe(idLabyrinthe) {
        
        document.getElementById("horloge").style.display = "none";

        var c = document.getElementsByTagName("canvas");
        document.getElementById("main").removeChild(c[0]);

        if (idLabyrinthe == "1") {
            EnvoieChoix('C4O1');
            EnvoieChoix('Fin1');
            ModifieEtat('15', 'B');
        } else if (idLabyrinthe == "2") {
            EnvoieChoix('C5O1');
            ModifieEtat('17', 'E');
        } else {
            EnvoieChoix('C8O1');
            ModifieEtat('26', 'E');
        }
        
    }


    //Fonction qui sort du labyrinthe s'il est perdant.
    
    function EchecLabyrinthe(idLabyrinthe) {
        
        document.getElementById("horloge").style.display = "none";

        var c = document.getElementsByTagName("canvas");
        document.getElementById("main").removeChild(c[0]);

        if (idLabyrinthe == "1") {
            EnvoieChoix('C4O2');
            ModifieEtat('16', 'D');
        } else if (idLabyrinthe == "2") {
            EnvoieChoix('C5O2');
            ModifieEtat('18', '9');
        } else {
            ModifieEtat('35', 'L');
            EnvoieChoix('C8O2')
        }
        
    }


</script>

</body>

</html>