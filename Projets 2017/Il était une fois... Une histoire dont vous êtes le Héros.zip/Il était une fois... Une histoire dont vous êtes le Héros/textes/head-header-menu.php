<?php session_start(); ?>

   
<!DOCTYPE HTML>

<html lang = 'fr'>

<head>

    <meta charset = "UTF-8">
    <meta name = "description" content  = "La Belle au bois dormant">
    <meta name = "keywords" content = "Belle au bois dormant, Contes de fées, versions, jeu, Grimm, Perrault">
    <meta name = "auteur" content = "Coraline et Lina">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">


    <title>Le Bois dormant</title>
    <link rel = "stylesheet" type = "text/css" href = "stylejeu.css" media = "screen">
    <link href="https://fonts.googleapis.com/css?family=Astloch" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Vollkorn" rel="stylesheet"> 
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,300i,400,600" rel="stylesheet">

    <script src="./jquery/lib/jquery.js"></script>
	<script src="./jquery/dist/jquery.validate.js"></script>
	<script src="./jquery/dist/additional-methods.js"></script>


</head>



<body id = "body" onload = "TrouveEtat()">

    <header>   
        <button id = "hamburguer" onclick = "OuvreMenu()">&#9776;</button>

        <h1>Le Bois dormant</h1>

        <a id = "deconnexion" href = "/formulaires.php">Déconnexion</a>
    </header>

    <div id = "menu">
        <a href = "/jeu.php" id = "link">Jeu</a>
        <a href = "/presentation.php">Présentation</a>
        <a href = "/galerie.php" id = "lienGalerie">Galerie d'images</a>
        <a href = "/statistiques.php" id = "lienStat">Vos Choix</a>
    </div>

<!--  -->

<?php
    if (!isset($_SESSION["pseudo"])) {
?>

        <script>
            document.getElementById("lienStat").style.display = "none";
            document.getElementById("lienGalerie").style.display = "none";
            document.getElementById("deconnexion").innerHTML = "Connexion";
        </script>

<?php
    } else {
?>

        <script>
            document.getElementById("lienStat").style.display = "";
            document.getElementById("lienGalerie").style.display = "";
        </script>

<?php
    }
?>

<script>
        
    function OuvreMenu() {
        document.getElementById("menu").style.width = "250px";
        document.getElementById("hamburguer").onclick = Function("FermeMenu()");
        document.getElementById("hamburguer").innerHTML = "&#10005";
    }

    function FermeMenu() {
        document.getElementById("menu").style.width = "0";
        document.getElementById("hamburguer").onclick = Function("OuvreMenu()");
        document.getElementById("hamburguer").innerHTML = "&#9776;";
    }


</script>