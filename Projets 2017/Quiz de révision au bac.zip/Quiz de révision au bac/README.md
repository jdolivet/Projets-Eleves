Projet réalisé par :

	Ines Hidalgo
	
	Isabela Castro
	
Remarque : utilise la bibliothèque pandas 

Attention à la bibliothèque xlrd utilisé par pandas pour les fichiers Excel

http://pandas.pydata.org/pandas-docs/stable/install.html#optional-dependencies
