CASE = 100
NB_RANGÉE = 6
NB_COLONNE = 7
COULEUR = {1:"red", 2:"yellow"}
